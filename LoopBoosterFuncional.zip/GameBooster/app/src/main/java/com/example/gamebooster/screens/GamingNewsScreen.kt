package com.example.gamebooster.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.gamebooster.R
import com.example.gamebooster.ui.theme.Montserrat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.draw.alpha

@Composable
fun GamingNewsScreen(isDarkTheme: Boolean, selectedLanguage: String) {
    val context = LocalContext.current
    var newsList by remember { mutableStateOf<List<GamingNews>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    val apiKey = "f20fa6ce1acd7ad1550d77ae8accacaf"
    val lang = if (selectedLanguage == "Spanish") "es" else "en"
    val apiUrl = "https://gnews.io/api/v4/search?q=gaming&lang=$lang&token=$apiKey&max=10"

    LaunchedEffect(selectedLanguage) {
        isLoading = true
        error = null
        try {
            val result = withContext(Dispatchers.IO) {
                URL(apiUrl).readText()
            }
            val json = JSONObject(result)
            val articles = json.getJSONArray("articles")
            val list = mutableListOf<GamingNews>()
            for (i in 0 until articles.length()) {
                val item = articles.getJSONObject(i)
                list.add(
                    GamingNews(
                        title = item.getString("title"),
                        description = item.optString("description", ""),
                        url = item.getString("url"),
                        image = item.optString("image", "")
                    )
                )
            }
            newsList = list
        } catch (e: Exception) {
            error = e.localizedMessage ?: "Error"
        }
        isLoading = false
    }

    val backgroundColor = if (isDarkTheme) Color.Black else Color(0xFFF5F5E6)
    val textColor = if (isDarkTheme) Color.White else Color.Black
    val cardColor = if (isDarkTheme) Color(0xFF1A1A1A) else Color.White

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
            .padding(16.dp)
    ) {
        Text(
            text = stringResource(R.string.gaming_news),
            fontFamily = Montserrat,
            fontWeight = FontWeight.Bold,
            fontSize = 28.sp,
            color = textColor,
            modifier = Modifier.padding(bottom = 16.dp)
        )
        if (isLoading) {
            val shimmerAlpha = rememberInfiniteTransition().animateFloat(
                initialValue = 0.3f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1000, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                )
            ).value
            Column(modifier = Modifier.fillMaxSize()) {
                repeat(5) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .alpha(shimmerAlpha),
                        colors = CardDefaults.cardColors(containerColor = cardColor),
                        shape = MaterialTheme.shapes.medium
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .background(
                                        Color.Gray.copy(alpha = 0.3f),
                                        shape = MaterialTheme.shapes.medium
                                    )
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .height(18.dp)
                                        .fillMaxWidth(0.7f)
                                        .background(
                                            Color.Gray.copy(alpha = 0.3f),
                                            shape = MaterialTheme.shapes.medium
                                        )
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Box(
                                    modifier = Modifier
                                        .height(14.dp)
                                        .fillMaxWidth(0.5f)
                                        .background(
                                            Color.Gray.copy(alpha = 0.2f),
                                            shape = MaterialTheme.shapes.medium
                                        )
                                )
                            }
                        }
                    }
                }
            }
        } else if (error != null) {
            Text(
                text = error ?: "Error",
                color = Color.Red,
                fontFamily = Montserrat,
                modifier = Modifier.padding(16.dp)
            )
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(newsList) { news ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .clickable {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(news.url))
                                context.startActivity(intent)
                            },
                        colors = CardDefaults.cardColors(containerColor = cardColor),
                        shape = MaterialTheme.shapes.medium
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (news.image.isNotEmpty()) {
                                Image(
                                    painter = rememberAsyncImagePainter(news.image),
                                    contentDescription = news.title,
                                    modifier = Modifier.size(64.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = news.title,
                                    fontFamily = Montserrat,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = textColor
                                )
                                if (news.description.isNotEmpty()) {
                                    Text(
                                        text = news.description,
                                        fontFamily = Montserrat,
                                        fontWeight = FontWeight.Normal,
                                        fontSize = 14.sp,
                                        color = textColor.copy(alpha = 0.7f),
                                        maxLines = 2
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

data class GamingNews(
    val title: String,
    val description: String,
    val url: String,
    val image: String
) 