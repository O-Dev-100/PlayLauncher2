package com.example.gamebooster.work

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.example.gamebooster.viewmodel.BoosterViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

class AutoBoostWorker @Inject constructor(
    @ApplicationContext context: Context,
    params: WorkerParameters,
    private val viewModel: BoosterViewModel
) : Worker(context, params) {

    override fun doWork(): Result {
        return Result.success()
    }
}