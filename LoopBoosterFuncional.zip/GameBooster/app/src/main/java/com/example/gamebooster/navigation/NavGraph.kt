package com.example.gamebooster.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import com.google.accompanist.navigation.animation.AnimatedNavHost
import com.google.accompanist.navigation.animation.composable as animatedComposable
import com.google.accompanist.navigation.animation.rememberAnimatedNavController
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import com.example.gamebooster.screens.*
import com.example.gamebooster.viewmodel.BoosterViewModel

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun NavGraph(
    navController: NavHostController,
    viewModel: BoosterViewModel,
    isDarkTheme: Boolean,
    selectedLanguage: String,
    onThemeChange: (Boolean) -> Unit,
    onLanguageChange: (String) -> Unit
) {
    AnimatedNavHost(
        navController = navController,
        startDestination = "welcome",
        enterTransition = { fadeIn(animationSpec = tween(350)) + slideInHorizontally(initialOffsetX = { it / 4 }, animationSpec = tween(350)) },
        exitTransition = { fadeOut(animationSpec = tween(350)) + slideOutHorizontally(targetOffsetX = { -it / 4 }, animationSpec = tween(350)) },
        popEnterTransition = { fadeIn(animationSpec = tween(350)) + slideInHorizontally(initialOffsetX = { -it / 4 }, animationSpec = tween(350)) },
        popExitTransition = { fadeOut(animationSpec = tween(350)) + slideOutHorizontally(targetOffsetX = { it / 4 }, animationSpec = tween(350)) }
    ) {
        animatedComposable("welcome") {
            WelcomeScreen(
                navController = navController,
                isDarkTheme = isDarkTheme,
                onThemeToggle = { onThemeChange(!isDarkTheme) },
                selectedLanguage = selectedLanguage,
                onLanguageChange = onLanguageChange
            )
        }
        animatedComposable("dashboard") {
            DashboardScreen(
                navController = navController,
                viewModel = viewModel,
                isDarkTheme = isDarkTheme,
                selectedLanguage = selectedLanguage
            )
        }
        animatedComposable("stats") {
            StatsScreen(
                navController = navController,
                viewModel = viewModel,
                isDarkTheme = isDarkTheme,
                selectedLanguage = selectedLanguage,
                onThemeChange = onThemeChange,
                onLanguageChange = onLanguageChange
            )
        }
        animatedComposable("ai_analysis") {
            AIAnalysisScreen(
                navController = navController,
                viewModel = viewModel,
                isDarkTheme = isDarkTheme,
                selectedLanguage = selectedLanguage,
                onThemeChange = onThemeChange,
                onLanguageChange = onLanguageChange
            )
        }
        animatedComposable("gfx_tool") {
            GFXToolScreen(
                navController = navController,
                viewModel = viewModel,
                isDarkTheme = isDarkTheme,
                selectedLanguage = selectedLanguage,
                onThemeChange = onThemeChange,
                onLanguageChange = onLanguageChange
            )
        }
        animatedComposable("profile") {
            ProfileScreen(
                navController = navController,
                viewModel = viewModel,
                isDarkTheme = isDarkTheme,
                selectedLanguage = selectedLanguage,
                onThemeChange = onThemeChange,
                onLanguageChange = onLanguageChange
            )
        }
        animatedComposable("history") {
            HistoryScreen(
                navController = navController,
                viewModel = viewModel,
                isDarkTheme = isDarkTheme,
                selectedLanguage = selectedLanguage
            )
        }
        animatedComposable("sidebar") {
            SidebarScreen(
                navController = navController,
                isDarkTheme = isDarkTheme,
                selectedLanguage = selectedLanguage,
                onThemeChange = onThemeChange,
                onLanguageChange = onLanguageChange
            )
        }
        animatedComposable("support") {
            SupportScreen(
                navController = navController,
                viewModel = viewModel
            )
        }
        animatedComposable("game_list") {
            GameListScreen(
                navController = navController,
                viewModel = viewModel,
                isDarkTheme = isDarkTheme,
                selectedLanguage = selectedLanguage
            )
        }
        animatedComposable("boost_configs") {
            BoostConfigsScreen(
                navController = navController,
                viewModel = viewModel,
                isDarkTheme = isDarkTheme,
                selectedLanguage = selectedLanguage
            )
        }
        animatedComposable("optimize") {
            OptimizeScreen(
                navController = navController
            )
        }
        animatedComposable("gaming_news") {
            GamingNewsScreen(
                isDarkTheme = isDarkTheme,
                selectedLanguage = selectedLanguage
            )
        }
    }
}