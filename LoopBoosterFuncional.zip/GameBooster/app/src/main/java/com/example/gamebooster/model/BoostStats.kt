package com.example.gamebooster.model

data class BoostStats(
    val ramUsage: Int = 0,
    val storageUsage: String = "0 GB / 0 GB",
    val ping: Int = 0,
    val temperature: Float = 0f,
    val batteryLevel: Int = 0
)