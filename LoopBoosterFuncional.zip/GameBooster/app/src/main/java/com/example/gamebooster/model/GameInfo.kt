package com.example.gamebooster.model

data class GameInfo(
    val packageName: String,
    val name: String,
    val isRunning: Boolean = false,
    val isOptimized: Boolean = false
)