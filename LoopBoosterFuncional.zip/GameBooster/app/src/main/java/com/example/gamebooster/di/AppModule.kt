package com.example.gamebooster.di

import android.content.Context
import android.content.SharedPreferences
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import androidx.room.Room
import com.example.gamebooster.data.AppDatabase
import com.example.gamebooster.data.BoostHistoryDao
import com.example.gamebooster.data.InstalledAppsRepository

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideSharedPreferences(@ApplicationContext context: Context): SharedPreferences {
        return context.getSharedPreferences("gamebooster_prefs", Context.MODE_PRIVATE)
    }

    @Provides
    @Singleton
    fun provideAppDatabase(@ApplicationContext context: Context): AppDatabase {
        return Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "gamebooster_db"
        ).build()
    }

    @Provides
    @Singleton
    fun provideBoostHistoryDao(db: AppDatabase): BoostHistoryDao {
        return db.boostHistoryDao()
    }

    @Provides
    @Singleton
    fun provideInstalledAppsRepository(@ApplicationContext context: Context): InstalledAppsRepository {
        return InstalledAppsRepository(context)
    }
}