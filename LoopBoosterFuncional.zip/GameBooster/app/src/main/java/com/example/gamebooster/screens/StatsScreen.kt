package com.example.gamebooster.screens

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.gamebooster.R
import com.example.gamebooster.viewmodel.BoosterViewModel
import com.example.gamebooster.ui.theme.Montserrat

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsScreen(
    navController: NavController,
    viewModel: BoosterViewModel,
    isDarkTheme: Boolean,
    selectedLanguage: String,
    onThemeChange: (Boolean) -> Unit,
    onLanguageChange: (String) -> Unit
) {
    val fps by viewModel.fps.collectAsState()
    val ping by viewModel.ping.collectAsState()
    val ramUsage by viewModel.ramUsage.collectAsState()
    val storageUsage by viewModel.storageUsage.collectAsState()
    val batteryLevel by viewModel.batteryLevel.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.stats), fontSize = 20.sp) },
                actions = {
                    var expanded by remember { mutableStateOf(false) }
                    IconButton(onClick = { expanded = true }) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "More options"
                        )
                    }
                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("AI Analysis") },
                            onClick = {
                                navController.navigate("ai_analysis")
                                expanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("GFX Tool") },
                            onClick = {
                                navController.navigate("gfx_tool")
                                expanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Profile") },
                            onClick = {
                                navController.navigate("profile")
                                expanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(if (isDarkTheme) "Light Theme" else "Dark Theme") },
                            onClick = {
                                onThemeChange(!isDarkTheme)
                                expanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(if (selectedLanguage == "English") "Spanish" else "English") },
                            onClick = {
                                onLanguageChange(if (selectedLanguage == "English") "Spanish" else "English")
                                expanded = false
                            }
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp)
                .animateContentSize(animationSpec = tween(300)),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = stringResource(R.string.device_performance),
                style = MaterialTheme.typography.headlineMedium,
                fontFamily = Montserrat,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                CircularProgressIndicator(
                    progress = ramUsage / 100f,
                    modifier = Modifier.size(120.dp),
                    color = MaterialTheme.colorScheme.primary,
                    strokeWidth = 10.dp
                )
                CircularProgressIndicator(
                    progress = storageUsage / 100f,
                    modifier = Modifier.size(120.dp),
                    color = MaterialTheme.colorScheme.secondary,
                    strokeWidth = 10.dp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = stringResource(R.string.ram) + ": ${String.format("%.1f", ramUsage)}%",
                        style = MaterialTheme.typography.bodyLarge,
                        fontFamily = Montserrat
                    )
                    Text(
                        text = stringResource(R.string.storage) + ": ${String.format("%.1f", storageUsage)}%",
                        style = MaterialTheme.typography.bodyLarge,
                        fontFamily = Montserrat
                    )
                    Text(
                        text = stringResource(R.string.battery_level) + ": $batteryLevel%",
                        style = MaterialTheme.typography.bodyLarge,
                        fontFamily = Montserrat
                    )
                    Text(
                        text = stringResource(R.string.fps) + ": $fps",
                        style = MaterialTheme.typography.bodyLarge,
                        fontFamily = Montserrat,
                        color = if (fps >= 60) Color.Green else Color.Red
                    )
                    Text(
                        text = stringResource(R.string.ping) + ": $ping ms",
                        style = MaterialTheme.typography.bodyLarge,
                        fontFamily = Montserrat,
                        color = if (ping <= 50) Color.Green else Color.Red
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { viewModel.optimizeDevice() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Text(stringResource(R.string.boost_now), fontSize = 16.sp, fontFamily = Montserrat)
            }
        }
    }
}