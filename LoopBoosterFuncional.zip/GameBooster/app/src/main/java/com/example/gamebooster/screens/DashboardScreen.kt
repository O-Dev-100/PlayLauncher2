package com.example.gamebooster.screens

import android.os.Vibrator
import android.os.VibrationEffect
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.rememberLottieComposition
import com.airbnb.lottie.compose.LottieConstants
import com.example.gamebooster.R
import com.example.gamebooster.ui.theme.Montserrat
import com.example.gamebooster.viewmodel.BoosterViewModel
import kotlin.math.min
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import kotlin.random.Random
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Abc
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Tune
import androidx.compose.ui.text.style.TextAlign

@Composable
fun DashboardScreen(
    navController: NavController,
    viewModel: BoosterViewModel,
    isDarkTheme: Boolean,
    selectedLanguage: String
) {
    val ramUsage by viewModel.ramUsage.collectAsState()
    val batteryLevel by viewModel.batteryLevel.collectAsState()
    val storageUsage by viewModel.storageUsage.collectAsState()
    val isOptimizing by viewModel.isOptimizing.collectAsState()
    val ultraBoost by viewModel.ultraBoost.collectAsState()
    val autoBoost by viewModel.autoBoost.collectAsState()
    val normalBoost by viewModel.normalBoost.collectAsState()
    val fps by viewModel.fps.collectAsState()
    val ping by viewModel.ping.collectAsState()
    val boostHistory by viewModel.boostHistory.collectAsState()

    val animatedRamUsage by animateFloatAsState(targetValue = ramUsage)
    val animatedStorageUsage by animateFloatAsState(targetValue = storageUsage)
    val backgroundColor = if (isDarkTheme) Color.Black else Color(0xFFF5F5E6)
    val textColor = if (isDarkTheme) Color.White else Color.Black
    val cardColor = if (isDarkTheme) Color(0xFF1A1A1A) else Color.White

    val boostComposition by rememberLottieComposition(LottieCompositionSpec.RawRes(R.raw.boost_effect))
    val powerIcon = painterResource(id = R.drawable.ic_power)
    val homeIcon = painterResource(id = R.drawable.ic_home)
    val newsIcon = painterResource(id = R.drawable.ic_placeholder)
    val profileIcon = painterResource(id = R.drawable.ic_achievement)

    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var showSuccess by remember { mutableStateOf(false) }
    var buttonScale by remember { mutableStateOf(1f) }

    // Animación de fondo sutil
    val infiniteTransition = rememberInfiniteTransition()
    val animatedOffset = infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    ).value

    // Juegos simulados para acceso rápido
    val quickGames = remember {
        listOf(
            "PUBG Mobile" to "battle_royale",
            "Call of Duty" to "fps",
            "Genshin Impact" to "rpg",
            "Minecraft" to "sandbox",
            "Roblox" to "social"
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = if (isDarkTheme)
                        listOf(Color(0xFF232526), Color(0xFF414345), Color(0xFF232526))
                    else
                        listOf(Color(0xFFF5F5E6), Color(0xFFE0E0D1), Color(0xFFF5F5E6)),
                    start = Offset(animatedOffset, 0f),
                    end = Offset(0f, animatedOffset),
                    tileMode = TileMode.Mirror
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header con branding
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = stringResource(R.string.welcome_title),
                        fontFamily = Montserrat,
                        fontWeight = FontWeight.Bold,
                        fontSize = 28.sp,
                        color = textColor
                    )
                    Text(
                        text = stringResource(R.string.welcome_subtitle),
                        fontFamily = Montserrat,
                        fontWeight = FontWeight.Normal,
                        fontSize = 16.sp,
                        color = textColor.copy(alpha = 0.7f)
                    )
                }
                IconButton(onClick = { navController.navigate("sidebar") }) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_menu),
                        contentDescription = "open sidebar",
                        tint = textColor
                    )
                }
            }

            // Tip del día con animación
            val tips = listOf(
                stringResource(R.string.tip_close_apps),
                stringResource(R.string.tip_dark_mode),
                stringResource(R.string.tip_optimize_before_gaming),
                stringResource(R.string.tip_update_device),
                stringResource(R.string.tip_hydrate),
                stringResource(R.string.tip_disable_notifications),
                stringResource(R.string.tip_ultra_boost),
                stringResource(R.string.tip_consistency)
            )
            val tipOfDay = remember { tips[Random.nextInt(tips.size)] }
            val tipCardElevation by animateDpAsState(
                targetValue = if (isOptimizing) 8.dp else 4.dp,
                animationSpec = tween(500)
            )
            
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .shadow(tipCardElevation, RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = cardColor),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.TrendingUp,
                        contentDescription = stringResource(R.string.tip_icon),
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = tipOfDay,
                        fontFamily = Montserrat,
                        fontWeight = FontWeight.Normal,
                        fontSize = 16.sp,
                        color = textColor
                    )
                }
            }

            // Estadísticas rápidas
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                StatCard(
                    title = stringResource(R.string.boosts_done, boostHistory.size),
                    value = "${boostHistory.size}",
                    icon = Icons.Default.TrendingUp,
                    color = MaterialTheme.colorScheme.primary,
                    isDarkTheme = isDarkTheme
                )
                StatCard(
                    title = stringResource(R.string.ram),
                    value = "${String.format("%.1f", animatedRamUsage)}%",
                    icon = Icons.Default.Settings,
                    color = if (animatedRamUsage > 80) Color.Red else Color.Green,
                    isDarkTheme = isDarkTheme
                )
                StatCard(
                    title = stringResource(R.string.battery_level),
                    value = "$batteryLevel%",
                    icon = Icons.Default.PlayArrow,
                    color = if (batteryLevel < 20) Color.Red else Color.Green,
                    isDarkTheme = isDarkTheme
                )
            }

            // Botón de boost principal con animación mejorada
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Box(contentAlignment = Alignment.Center) {
                    if (isOptimizing) {
                        LottieAnimation(
                            composition = boostComposition,
                            iterations = LottieConstants.IterateForever,
                            modifier = Modifier.size(140.dp)
                        )
                    }
                    Button(
                        onClick = {
                            val vibrator = context.getSystemService(android.content.Context.VIBRATOR_SERVICE) as? Vibrator
                            vibrator?.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
                            viewModel.optimizeDevice()
                            showSuccess = true
                            scope.launch {
                                snackbarHostState.showSnackbar("¡Dispositivo optimizado con éxito!")
                                showSuccess = false
                            }
                        },
                        enabled = !isOptimizing,
                        shape = CircleShape,
                        modifier = Modifier
                            .size(120.dp)
                            .shadow(12.dp, CircleShape)
                            .graphicsLayer {
                                scaleX = buttonScale
                                scaleY = buttonScale
                            },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isDarkTheme) Color.White else Color.Black,
                            contentColor = if (isDarkTheme) Color.Black else Color.White
                        )
                    ) {
                        Icon(
                            painter = powerIcon,
                            contentDescription = "Boost",
                            modifier = Modifier.size(64.dp),
                            tint = if (isDarkTheme) Color.Black else Color.White
                        )
                    }
                }
            }

            // Juegos de acceso rápido
            Text(
                text = stringResource(R.string.quick_access),
                fontFamily = Montserrat,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = textColor,
                modifier = Modifier.padding(vertical = 8.dp)
            )
            
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(quickGames) { (gameName, gameType) ->
                    QuickGameCard(
                        gameName = gameName,
                        gameType = gameType,
                        onClick = {
                            scope.launch {
                                snackbarHostState.showSnackbar("Iniciando $gameName...")
                            }
                        },
                        isDarkTheme = isDarkTheme
                    )
                }
            }

            // Accesos rápidos a funciones
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                QuickAccessButton(
                    icon = Icons.Default.Gamepad,
                    label = stringResource(R.string.games),
                    onClick = { navController.navigate("game_list") },
                    isDarkTheme = isDarkTheme
                )
                QuickAccessButton(
                    icon = Icons.Default.History,
                    label = stringResource(R.string.history),
                    onClick = { navController.navigate("history") },
                    isDarkTheme = isDarkTheme
                )
                QuickAccessButton(
                    icon = Icons.Default.Abc,
                    label = stringResource(R.string.news),
                    onClick = { navController.navigate("gaming_news") },
                    isDarkTheme = isDarkTheme
                )
                QuickAccessButton(
                    icon = Icons.Default.Tune,
                    label = stringResource(R.string.config),
                    onClick = { navController.navigate("boost_configs") },
                    isDarkTheme = isDarkTheme
                )
            }

            // Métricas en tiempo real
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = cardColor),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    MetricItem(
                        label = stringResource(R.string.fps),
                        value = "$fps",
                        isDarkTheme = isDarkTheme
                    )
                    MetricItem(
                        label = stringResource(R.string.ping),
                        value = "$ping ms",
                        isDarkTheme = isDarkTheme
                    )
                    MetricItem(
                        label = stringResource(R.string.storage),
                        value = "${String.format("%.1f", animatedStorageUsage)}%",
                        isDarkTheme = isDarkTheme
                    )
                }
            }

            // BottomBar simplificado
            NavigationBar(
                containerColor = if (isDarkTheme) Color(0xFF1A1A1A) else Color.White
            ) {
                NavigationBarItem(
                    selected = true,
                    onClick = { },
                    icon = { Icon(homeIcon, contentDescription = stringResource(R.string.dashboard)) },
                    label = { Text(stringResource(R.string.dashboard), fontFamily = Montserrat) }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { navController.navigate("gaming_news") },
                    icon = { Icon(newsIcon, contentDescription = stringResource(R.string.news)) },
                    label = { Text(stringResource(R.string.news), fontFamily = Montserrat) }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { navController.navigate("profile") },
                    icon = { Icon(profileIcon, contentDescription = stringResource(R.string.profile)) },
                    label = { Text(stringResource(R.string.profile), fontFamily = Montserrat) }
                )
            }

            SnackbarHost(hostState = snackbarHostState)
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    isDarkTheme: Boolean
) {
    val cardColor = if (isDarkTheme) Color(0xFF1A1A1A) else Color.White
    val textColor = if (isDarkTheme) Color.White else Color.Black
    
    Card(
        modifier = Modifier
            .padding(4.dp)
            .shadow(4.dp, RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontFamily = Montserrat,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = textColor
            )
            Text(
                text = title,
                fontFamily = Montserrat,
                fontWeight = FontWeight.Normal,
                fontSize = 12.sp,
                color = textColor.copy(alpha = 0.7f),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun QuickGameCard(
    gameName: String,
    gameType: String,
    onClick: () -> Unit,
    isDarkTheme: Boolean
) {
    val cardColor = if (isDarkTheme) Color(0xFF1A1A1A) else Color.White
    val textColor = if (isDarkTheme) Color.White else Color.Black
    
    Card(
        modifier = Modifier
            .width(100.dp)
            .clickable { onClick() }
            .shadow(4.dp, RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Gamepad,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = gameName,
                fontFamily = Montserrat,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = textColor,
                textAlign = TextAlign.Center
            )
            Text(
                text = gameType,
                fontFamily = Montserrat,
                fontWeight = FontWeight.Normal,
                fontSize = 10.sp,
                color = textColor.copy(alpha = 0.7f),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun QuickAccessButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    isDarkTheme: Boolean
) {
    val cardColor = if (isDarkTheme) Color(0xFF1A1A1A) else Color.White
    val textColor = if (isDarkTheme) Color.White else Color.Black
    
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = cardColor),
        modifier = Modifier.padding(4.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = label,
                fontFamily = Montserrat,
                fontSize = 12.sp,
                color = textColor
            )
        }
    }
}

@Composable
fun MetricItem(
    label: String,
    value: String,
    isDarkTheme: Boolean
) {
    val textColor = if (isDarkTheme) Color.White else Color.Black
    
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = label,
            fontFamily = Montserrat,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = textColor.copy(alpha = 0.7f)
        )
        Text(
            text = value,
            fontFamily = Montserrat,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = textColor
        )
    }
}