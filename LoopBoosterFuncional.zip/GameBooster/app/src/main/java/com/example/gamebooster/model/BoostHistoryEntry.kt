package com.example.gamebooster.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "boost_history")
data class BoostHistoryEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long, // momento en que se realizó el boost
    val ramFreed: Int, // ram liberada en mb
    val appsClosed: Int, // número de apps cerradas
    val type: String, // tipo de boost (quick, deep, etc.)
    val batterySaved: Int, // porcentaje de batería ahorrada
    val storageFreed: Int, // almacenamiento liberado en mb
    val duration: Long // duración del boost en milisegundos
)