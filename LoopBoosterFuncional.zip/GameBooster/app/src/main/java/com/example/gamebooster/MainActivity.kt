package com.example.gamebooster

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.navigation.compose.rememberNavController
import com.example.gamebooster.navigation.NavGraph
import com.example.gamebooster.ui.theme.GameBoosterTheme
import com.example.gamebooster.viewmodel.BoosterViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint 
class MainActivity : ComponentActivity() {
    
    private val viewModel: BoosterViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var isDarkTheme by remember { mutableStateOf(false) }
            var selectedLanguage by remember { mutableStateOf("English") }

            GameBoosterTheme(darkTheme = isDarkTheme) {
                val navController = rememberNavController()
                NavGraph(
                    navController = navController,
                    viewModel = viewModel,
                    isDarkTheme = isDarkTheme,
                    selectedLanguage = selectedLanguage,
                    onThemeChange = { isDarkTheme = it },
                    onLanguageChange = { selectedLanguage = it }
                )
            }
        }
    }
}