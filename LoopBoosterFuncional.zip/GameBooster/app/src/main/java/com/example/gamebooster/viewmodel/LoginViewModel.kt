package com.example.gamebooster.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.AuthCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val auth: FirebaseAuth
) : ViewModel() {

    private val _authState = MutableStateFlow<AuthState>(AuthState.Idle)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    sealed class AuthState {
        object Idle : AuthState()
        object Loading : AuthState()
        data class Success(val userId: String) : AuthState()
        data class Error(val message: String) : AuthState()
    }

    fun signInWithGoogle(idToken: AuthCredential, param: (Any, Any) -> Unit) {
        _authState.update { AuthState.Loading }
        viewModelScope.launch {
            try {
                val credential = GoogleAuthProvider.getCredential(idToken.toString(), null)
                auth.signInWithCredential(credential)
                    .addOnCompleteListener { task ->
                        _authState.update {
                            if (task.isSuccessful) {
                                AuthState.Success(auth.currentUser?.uid ?: "")
                            } else {
                                AuthState.Error("Google Sign-In failed: ${task.exception?.message}")
                            }
                        }
                    }
            } catch (e: Exception) {
                _authState.update { AuthState.Error("Error during Google Sign-In: ${e.message}") }
            }
        }
    }

    fun signInWithEmail(email: String, password: String) {
        _authState.update { AuthState.Loading }
        viewModelScope.launch {
            try {
                auth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener { task ->
                        _authState.update {
                            if (task.isSuccessful) {
                                AuthState.Success(auth.currentUser?.uid ?: "")
                            } else {
                                AuthState.Error("Email Sign-In failed: ${task.exception?.message}")
                            }
                        }
                    }
            } catch (e: Exception) {
                _authState.update { AuthState.Error("Error during Email Sign-In: ${e.message}") }
            }
        }
    }

    fun signOut() {
        auth.signOut()
        _authState.update { AuthState.Idle }
    }
}