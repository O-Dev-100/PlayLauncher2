package com.example.gamebooster.viewmodel

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.gamebooster.data.BoostHistoryDao
import com.example.gamebooster.data.InstalledAppsRepository
import com.example.gamebooster.model.BoostHistoryEntry
import com.example.gamebooster.model.InstalledApp
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class BoosterViewModel @Inject constructor(
    application: Application,
    private val boostHistoryDao: BoostHistoryDao,
    private val installedAppsRepository: InstalledAppsRepository
) : AndroidViewModel(application) {

    // Métricas del dispositivo
    private val _ramUsage = MutableStateFlow(0f)
    val ramUsage = _ramUsage.asStateFlow()

    private val _storageUsage = MutableStateFlow(0f)
    val storageUsage = _storageUsage.asStateFlow()

    private val _batteryLevel = MutableStateFlow(0)
    val batteryLevel = _batteryLevel.asStateFlow()

    private val _fps = MutableStateFlow(0)
    val fps = _fps.asStateFlow()

    private val _ping = MutableStateFlow(0)
    val ping = _ping.asStateFlow()

    private val _isOptimizing = MutableStateFlow(false)
    val isOptimizing = _isOptimizing.asStateFlow()

    // Estados de los modos de boost
    private val _ultraBoost = MutableStateFlow(false)
    val ultraBoost = _ultraBoost.asStateFlow()

    private val _autoBoost = MutableStateFlow(false)
    val autoBoost = _autoBoost.asStateFlow()

    private val _normalBoost = MutableStateFlow(false)
    val normalBoost = _normalBoost.asStateFlow()

    // Historial de Boost
    private val _boostHistory = MutableStateFlow<List<BoostHistoryEntry>>(emptyList())
    val boostHistory = _boostHistory.asStateFlow()

    // Aplicaciones instaladas
    private val _installedApps = MutableStateFlow<List<InstalledApp>>(emptyList())
    val installedApps = _installedApps.asStateFlow()

    init {
        // Inicializar datos
        updateDeviceMetrics()
        loadInstalledApps()
        viewModelScope.launch {
            boostHistoryDao.getAllBoosts().collect { history ->
                _boostHistory.value = history
            }
        }
    }

    private fun loadInstalledApps() {
        viewModelScope.launch {
            try {
                val apps = installedAppsRepository.getInstalledApps()
                _installedApps.value = apps
            } catch (e: Exception) {
                e.printStackTrace()
                // En caso de error, usar apps simuladas
                _installedApps.value = getSimulatedApps()
            }
        }
    }

    private fun getSimulatedApps(): List<InstalledApp> {
        return listOf(
            InstalledApp("com.pubg.mobile", "PUBG Mobile", null, true, "battle_royale"),
            InstalledApp("com.activision.callofduty", "Call of Duty", null, true, "fps"),
            InstalledApp("com.mihoyo.genshin", "Genshin Impact", null, true, "rpg"),
            InstalledApp("com.mojang.minecraft", "Minecraft", null, true, "sandbox"),
            InstalledApp("com.roblox.client", "Roblox", null, true, "social")
        )
    }

    fun launchApp(packageName: String) {
        viewModelScope.launch {
            installedAppsRepository.launchApp(packageName)
        }
    }

    private fun updateDeviceMetrics() {
        // Obtener RAM disponible
        val activityManager = getApplication<Application>().getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        val totalRam = memoryInfo.totalMem / (1024 * 1024) // MB
        val availRam = memoryInfo.availMem / (1024 * 1024) // MB
        _ramUsage.value = ((totalRam - availRam) / totalRam.toFloat()) * 100

        // Simular almacenamiento, batería, FPS y ping (sustituir por datos reales en el futuro)
        _storageUsage.value = 75f
        _batteryLevel.value = 80
        _fps.value = 60
        _ping.value = 30

        // Actualizar métricas periódicamente
        viewModelScope.launch {
            while (true) {
                activityManager.getMemoryInfo(memoryInfo)
                _ramUsage.value = ((totalRam - memoryInfo.availMem / (1024 * 1024)) / totalRam.toFloat()) * 100
                _fps.value = (50..120).random()
                _ping.value = (20..100).random()
                kotlinx.coroutines.delay(5000)
            }
        }
    }

    fun toggleUltraBoost() {
        _ultraBoost.value = !_ultraBoost.value
    }

    fun toggleAutoBoost() {
        _autoBoost.value = !_autoBoost.value
    }

    fun toggleNormalBoost() {
        _normalBoost.value = !_normalBoost.value
    }

    fun optimizeDevice() {
        viewModelScope.launch {
            _isOptimizing.value = true
            val startTime = System.currentTimeMillis()

            // Simular optimización (sustituir por cierre real de procesos)
            val ramFreed = (100..500).random()
            val appsClosed = (1..10).random()
            val batterySaved = (1..5).random()
            val storageFreed = (50..200).random()
            val duration = System.currentTimeMillis() - startTime

            // Actualizar estados
            _ramUsage.value = (_ramUsage.value - (ramFreed / 10f)).coerceAtLeast(0f)
            _storageUsage.value = (_storageUsage.value - (storageFreed / 100f)).coerceAtLeast(0f)
            _batteryLevel.value = (_batteryLevel.value + batterySaved).coerceAtMost(100)
            _fps.value = (_fps.value + 10).coerceAtMost(120)
            _ping.value = (_ping.value - 5).coerceAtLeast(10)

            // Guardar en historial
            val entry = BoostHistoryEntry(
                timestamp = System.currentTimeMillis(),
                ramFreed = ramFreed,
                appsClosed = appsClosed,
                type = when {
                    _ultraBoost.value -> "Ultra"
                    _autoBoost.value -> "Auto"
                    _normalBoost.value -> "Normal"
                    else -> "Manual"
                },
                batterySaved = batterySaved,
                storageFreed = storageFreed,
                duration = duration
            )
            boostHistoryDao.insertBoost(entry)

            _isOptimizing.value = false
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            boostHistoryDao.clearHistory()
        }
    }
}