package com.example.gamebooster.data

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.gamebooster.model.BoostHistoryEntry

@Database(entities = [BoostHistoryEntry::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun boostHistoryDao(): BoostHistoryDao
}